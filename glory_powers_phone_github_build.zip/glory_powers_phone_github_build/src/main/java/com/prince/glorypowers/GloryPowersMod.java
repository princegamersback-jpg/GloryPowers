package com.prince.glorypowers;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.world.World;

public class GloryPowersMod implements ModInitializer {
    public static final String MOD_ID = "glorypowers";

    public static final Item THUNDER_CORE = register("thunder_core",
        new Item(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
    public static final Item TITAN_HEART = register("titan_heart",
        new Item(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
    public static final Item SHADOW_ORB = register("shadow_orb",
        new Item(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
    public static final Item GLORY_BLADE = register("glory_blade",
        new Item(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).attributeModifiers(
            net.minecraft.item.ToolMaterials.NETHERITE.createSwordAttributes(8.0F, -2.2F))));
    public static final Item TITAN_AXE = register("titan_axe",
        new Item(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).attributeModifiers(
            net.minecraft.item.ToolMaterials.NETHERITE.createSwordAttributes(12.0F, -3.1F))));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(MOD_ID, name), item);
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(THUNDER_CORE);
            entries.add(TITAN_HEART);
            entries.add(SHADOW_ORB);
            entries.add(GLORY_BLADE);
            entries.add(TITAN_AXE);
        });

        // Right-click abilities: use the special item itself to activate the matching power.
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient) return ActionResult.PASS;

            if (stack.is(THUNDER_CORE)) {
                if (player instanceof ServerPlayerEntity serverPlayer) thunderPower(serverPlayer);
                return ActionResult.SUCCESS;
            }
            if (stack.is(TITAN_HEART) || stack.is(TITAN_AXE)) {
                if (player instanceof ServerPlayerEntity serverPlayer) titanPower(serverPlayer);
                return ActionResult.SUCCESS;
            }
            if (stack.is(SHADOW_ORB)) {
                if (player instanceof ServerPlayerEntity serverPlayer) shadowPower(serverPlayer);
                return ActionResult.SUCCESS;
            }
            if (stack.is(GLORY_BLADE)) {
                if (player instanceof ServerPlayerEntity serverPlayer) bladeBurst(serverPlayer);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("glory")
                .then(CommandManager.literal("help").executes(ctx -> {
                    ctx.getSource().sendFeedback(() -> Text.literal(
                        "Glory Powers: /glory give <thunder|titan|shadow|blade|axe>, " +
                        "/glory power <thunder|titan|shadow|blade|boss>, /glory boss spawn"), false);
                    return 1;
                }))
                .then(CommandManager.literal("give")
                    .requires(source -> source.hasPermissionLevel(2))
                    .then(CommandManager.literal("thunder").executes(ctx -> giveItem(ctx.getSource().getPlayerOrThrow(), THUNDER_CORE)))
                    .then(CommandManager.literal("titan").executes(ctx -> giveItem(ctx.getSource().getPlayerOrThrow(), TITAN_HEART)))
                    .then(CommandManager.literal("shadow").executes(ctx -> giveItem(ctx.getSource().getPlayerOrThrow(), SHADOW_ORB)))
                    .then(CommandManager.literal("blade").executes(ctx -> giveItem(ctx.getSource().getPlayerOrThrow(), GLORY_BLADE)))
                    .then(CommandManager.literal("axe").executes(ctx -> giveItem(ctx.getSource().getPlayerOrThrow(), TITAN_AXE))))
                .then(CommandManager.literal("power")
                    .then(CommandManager.literal("thunder").executes(ctx -> thunderPower(ctx.getSource().getPlayerOrThrow())))
                    .then(CommandManager.literal("titan").executes(ctx -> titanPower(ctx.getSource().getPlayerOrThrow())))
                    .then(CommandManager.literal("shadow").executes(ctx -> shadowPower(ctx.getSource().getPlayerOrThrow())))
                    .then(CommandManager.literal("blade").executes(ctx -> bladeBurst(ctx.getSource().getPlayerOrThrow())))
                    .then(CommandManager.literal("boss").executes(ctx -> spawnTitanLord(ctx.getSource().getPlayerOrThrow())))
                )
                .then(CommandManager.literal("boss")
                    .then(CommandManager.literal("spawn")
                        .requires(source -> source.hasPermissionLevel(2))
                        .executes(ctx -> spawnTitanLord(ctx.getSource().getPlayerOrThrow())))
                )
            );
        });
    }

    private static int giveItem(ServerPlayerEntity player, Item item) {
        ItemStack stack = new ItemStack(item);
        if (!player.getInventory().insertStack(stack)) player.dropItem(stack, false);
        player.sendMessage(Text.literal("You received " + item.getName().getString() + "!"), false);
        return 1;
    }

    private static int thunderPower(ServerPlayerEntity player) {
        LivingEntity target = findTarget(player, 12.0);
        if (target == null) {
            player.sendMessage(Text.literal("No nearby target found within 12 blocks."), false);
            return 0;
        }
        target.damage(player.getDamageSources().playerAttack(player), 12.0F);
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 1));
        player.sendMessage(Text.literal("Thunder strike!"), false);
        return 1;
    }

    private static int titanPower(ServerPlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 30, 2));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 30, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 20 * 8, 1));
        player.sendMessage(Text.literal("Titan power activated for 30 seconds!"), false);
        return 1;
    }

    private static int shadowPower(ServerPlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 20 * 15, 0));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 15, 1));
        player.sendMessage(Text.literal("Shadow power activated for 15 seconds!"), false);
        return 1;
    }

    private static int bladeBurst(ServerPlayerEntity player) {
        LivingEntity target = findTarget(player, 6.0);
        if (target != null) {
            target.damage(player.getDamageSources().playerAttack(player), 18.0F);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 20 * 4, 1));
            player.sendMessage(Text.literal("Glory Blade burst!"), false);
            return 1;
        }
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 4, 1));
        player.sendMessage(Text.literal("Glory Blade: no target nearby; burst speed granted."), false);
        return 1;
    }

    private static int spawnTitanLord(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        ZombieEntity boss = EntityType.ZOMBIE.create(world, SpawnReason.COMMAND);
        if (boss == null) {
            player.sendMessage(Text.literal("Could not create Titan Lord."), false);
            return 0;
        }
        boss.refreshPositionAndAngles(player.getX() + 2.0, player.getY(), player.getZ() + 2.0, player.getYaw(), 0.0F);
        boss.setCustomName(Text.literal("Titan Lord"));
        boss.setCustomNameVisible(true);
        boss.setPersistent();
        boss.setCanPickUpLoot(false);
        boss.setBaby(false);
        boss.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(300.0);
        boss.setHealth(300.0F);
        boss.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE).setBaseValue(18.0);
        boss.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED).setBaseValue(0.32);
        boss.getAttributeInstance(EntityAttributes.KNOCKBACK_RESISTANCE).setBaseValue(0.8);
        boss.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 60 * 30, 0));
        world.spawnEntity(boss);
        player.sendMessage(Text.literal("The Titan Lord has arrived! (300 HP, 18 damage)"), false);
        return 1;
    }

    private static LivingEntity findTarget(ServerPlayerEntity player, double range) {
        World world = player.getWorld();
        return world.getEntitiesByClass(LivingEntity.class, player.getBoundingBox().expand(range),
            entity -> entity != player && entity.isAlive() && player.canSee(entity))
            .stream()
            .min((a, b) -> Double.compare(player.squaredDistanceTo(a), player.squaredDistanceTo(b)))
            .orElse(null);
    }
}
