# Glory Powers — Fabric 1.21.10 (Titan Lord prototype)

This ZIP is a source project, not a precompiled or tested JAR.

## Implemented in source
- Custom registered items: Thunder Core, Titan Heart, Shadow Orb, Glory Blade, Titan Axe
- Right-click powers:
  - Thunder Core: damages and slows the nearest visible living target in 12 blocks
  - Titan Heart / Titan Axe: Strength, Resistance, and short Regeneration
  - Shadow Orb: Invisibility and Speed
  - Glory Blade: nearby burst damage/Weakness, or Speed if no target is nearby
- Commands:
  - `/glory help`
  - `/glory give thunder|titan|shadow|blade|axe` (admin permission level 2)
  - `/glory power thunder|titan|shadow|blade`
  - `/glory boss spawn` (admin permission level 2)
  - `/glory power boss` (spawn Titan Lord)
- Titan Lord prototype: a named, persistent, high-health zombie with boosted stats. This is a prototype using vanilla zombie visuals/AI, not a fully custom entity model.

## Build
Requirements: Java 21 JDK, Gradle, internet access.

Run from this folder:
```bash
gradle build
```
If it builds successfully, the mod JAR should be in `build/libs/`.

## Android
You can extract and edit the project on Android. Compiling Fabric mods directly on Android can be difficult due to Java/Gradle compatibility. A compatible Java 21 + Gradle environment is required.

## Troubleshooting
The dependency pins are starter values and have not been verified in this environment. If Gradle reports that a Loom/Yarn/Loader/Fabric API version does not exist, use the exact versions published for Minecraft 1.21.10. If compilation reports Java API errors, send the full error text and I can revise the source.


## Build online from a phone (GitHub Actions)

This project includes `.github/workflows/build.yml`. After uploading the project files to a GitHub repository:
1. Open the repository's **Actions** tab.
2. Select **Build Glory Powers**.
3. Tap **Run workflow** if shown, or push/commit a change to trigger the build.
4. Open the completed workflow run and find **Artifacts**.
5. Download `glory-powers-jar`, extract the downloaded artifact ZIP, and put the `.jar` inside Battly's Minecraft `mods` folder alongside Fabric API.

Note: this workflow tries to compile the source; it does not guarantee the source compiles successfully. If the build fails, open the run's build log and share the error text.
